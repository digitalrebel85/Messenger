const { Sequelize } = require('sequelize');
require('dotenv').config();

async function initDatabase() {
  // Connect to postgres to create the database
  const adminSequelize = new Sequelize('postgres', 'postgres', 'postgres', {
    host: 'localhost',
    port: 5432,
    dialect: 'postgres',
    logging: false
  });

  try {
    // Create the database if it doesn't exist
    await adminSequelize.query('CREATE DATABASE communications_db;');
    console.log('Database created successfully');
  } catch (error) {
    if (error.name === 'SequelizeDatabaseError') {
      console.log('Database already exists, continuing...');
    } else {
      console.error('Error creating database:', error);
    }
  } finally {
    await adminSequelize.close();
  }

  // Connect to the new database and sync models
  const appSequelize = new Sequelize(process.env.DATABASE_URL, {
    logging: false
  });

  try {
    await appSequelize.authenticate();
    console.log('Database connection successful');
    
    await appSequelize.sync({ force: true });
    console.log('Database tables created successfully');
  } catch (error) {
    console.error('Error syncing database:', error);
  } finally {
    await appSequelize.close();
  }
}

initDatabase();