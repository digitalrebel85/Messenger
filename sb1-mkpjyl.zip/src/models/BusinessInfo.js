const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const BusinessInfo = sequelize.define('BusinessInfo', {
    companyName: {
      type: DataTypes.STRING,
      allowNull: false
    },
    industry: {
      type: DataTypes.STRING,
      allowNull: false
    },
    productsServices: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    description: {
      type: DataTypes.TEXT
    },
    contactEmail: {
      type: DataTypes.STRING,
      validate: {
        isEmail: true
      }
    },
    phoneNumber: {
      type: DataTypes.STRING
    }
  });

  return BusinessInfo;
};