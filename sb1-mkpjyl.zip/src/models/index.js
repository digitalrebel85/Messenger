const { sequelize } = require('../config/database');
const defineMessage = require('./Message');

// Initialize models
const Message = defineMessage(sequelize);

// Export models and sequelize instance
module.exports = {
  sequelize,
  Message
};