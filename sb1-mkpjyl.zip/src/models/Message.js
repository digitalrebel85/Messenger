const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  return sequelize.define('Message', {
    content: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    channel: {
      type: DataTypes.ENUM('sms', 'whatsapp'),
      allowNull: false
    },
    direction: {
      type: DataTypes.ENUM('inbound', 'outbound'),
      allowNull: false
    },
    phoneNumber: {
      type: DataTypes.STRING,
      allowNull: false
    },
    status: {
      type: DataTypes.ENUM('pending', 'sent', 'received', 'failed'),
      defaultValue: 'pending'
    },
    error: {
      type: DataTypes.TEXT,
      allowNull: true
    }
  }, {
    tableName: 'messages',
    underscored: false,
    timestamps: true
  });
};