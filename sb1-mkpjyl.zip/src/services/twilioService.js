const twilio = require('twilio');

const client = twilio(
  process.env.TWILIO_ACCOUNT_SID || 'AC3c258ee77ce2ec3f7386ebf1fe6d4152',
  process.env.TWILIO_AUTH_TOKEN || '8140c1de6cd6f729864bf288e0f25770'
);

const TWILIO_PHONE_NUMBER = process.env.TWILIO_PHONE_NUMBER || '+44 7360 275267';

exports.sendSMS = async (to, body) => {
  try {
    const message = await client.messages.create({
      body,
      from: TWILIO_PHONE_NUMBER,
      to
    });
    return message.sid;
  } catch (error) {
    console.error('Error sending SMS:', error);
    throw new Error('Failed to send SMS message');
  }
};

exports.sendWhatsApp = async (to, body) => {
  try {
    const message = await client.messages.create({
      body,
      from: `whatsapp:${TWILIO_PHONE_NUMBER}`,
      to: `whatsapp:${to}`
    });
    return message.sid;
  } catch (error) {
    console.error('Error sending WhatsApp message:', error);
    throw new Error('Failed to send WhatsApp message');
  }
};

exports.validateWebhook = (req) => {
  const twilioSignature = req.headers['x-twilio-signature'];
  const url = `${req.protocol}://${req.get('host')}${req.originalUrl}`;
  return twilio.validateRequest(
    process.env.TWILIO_AUTH_TOKEN,
    twilioSignature,
    url,
    req.body
  );
};