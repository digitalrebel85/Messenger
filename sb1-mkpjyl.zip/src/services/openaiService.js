const { Configuration, OpenAIApi } = require('openai');

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY
});

const openai = new OpenAIApi(configuration);

exports.generateResponse = async (prompt) => {
  try {
    const response = await openai.createChatCompletion({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: "You are a helpful AI sales assistant. Provide professional, friendly, and helpful responses while maintaining a positive tone. Keep responses concise and under 150 words."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      max_tokens: 150,
      temperature: 0.7,
      top_p: 1.0,
      frequency_penalty: 0.0,
      presence_penalty: 0.0,
    });

    if (!response.data?.choices?.[0]?.message?.content) {
      throw new Error('No response generated');
    }

    return response.data.choices[0].message.content.trim();
  } catch (error) {
    console.error('Error generating AI response:', error.response?.data || error.message);
    throw new Error('Failed to generate AI response');
  }
};