const express = require('express');
const { body, validationResult } = require('express-validator');
const { BusinessInfo } = require('../models');
const router = express.Router();

router.post('/', [
  body('companyName').notEmpty().trim(),
  body('industry').notEmpty().trim(),
  body('productsServices').notEmpty(),
  body('contactEmail').optional().isEmail(),
  body('phoneNumber').optional().trim()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const businessInfo = await BusinessInfo.create({
      ...req.body,
      UserId: req.session.userId
    });

    res.status(201).json(businessInfo);
  } catch (error) {
    res.status(500).json({ 
      error: 'Failed to create business info',
      details: error.message 
    });
  }
});

router.get('/', async (req, res) => {
  try {
    const businessInfo = await BusinessInfo.findOne({
      where: { UserId: req.session.userId }
    });

    if (!businessInfo) {
      return res.status(404).json({ error: 'Business info not found' });
    }

    res.json(businessInfo);
  } catch (error) {
    res.status(500).json({ 
      error: 'Failed to fetch business info',
      details: error.message 
    });
  }
});

module.exports = router;