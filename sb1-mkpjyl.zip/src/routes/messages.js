const express = require('express');
const { Message } = require('../models');
const router = express.Router();

// Get messages page with auto-refresh
router.get('/', async (req, res) => {
  try {
    const messages = await Message.findAll({
      order: [['createdAt', 'DESC']],
      limit: 50
    });

    console.log('Retrieved messages:', messages.length);

    // Group messages by phone number for better display
    const groupedMessages = messages.reduce((acc, message) => {
      if (!acc[message.phoneNumber]) {
        acc[message.phoneNumber] = [];
      }
      acc[message.phoneNumber].push(message);
      return acc;
    }, {});

    res.render('messages', { 
      messages: messages,
      groupedMessages: groupedMessages,
      error: null 
    });
  } catch (error) {
    console.error('Error fetching messages:', error);
    res.render('messages', { 
      messages: [], 
      groupedMessages: {},
      error: 'Failed to load messages. Please try again.' 
    });
  }
});

module.exports = router;