const express = require('express');
const router = express.Router();
const { Message } = require('../models');
const twilioService = require('../services/twilioService');
const openaiService = require('../services/openaiService');

// Handle incoming messages from Twilio
router.post('/twilio', async (req, res) => {
  try {
    // Log incoming webhook data
    console.log('Webhook payload:', req.body);
    
    const { Body: content, From: from, To: to } = req.body;
    const isWhatsApp = from.startsWith('whatsapp:');
    const phoneNumber = isWhatsApp ? from.replace('whatsapp:', '') : from;
    const channel = isWhatsApp ? 'whatsapp' : 'sms';

    console.log(`Received ${channel} message from ${phoneNumber}: ${content}`);

    // Store the inbound message
    const inboundMessage = await Message.create({
      content,
      channel,
      phoneNumber,
      direction: 'inbound',
      status: 'received'
    });

    console.log('Stored inbound message:', inboundMessage.toJSON());

    try {
      // Generate AI response
      const aiResponse = await openaiService.generateResponse(content);
      console.log(`AI Response: ${aiResponse}`);

      // Send AI response
      if (isWhatsApp) {
        await twilioService.sendWhatsApp(phoneNumber, aiResponse);
      } else {
        await twilioService.sendSMS(phoneNumber, aiResponse);
      }

      // Store the outbound message
      const outboundMessage = await Message.create({
        content: aiResponse,
        channel,
        phoneNumber,
        direction: 'outbound',
        status: 'sent'
      });

      console.log('Stored outbound message:', outboundMessage.toJSON());
    } catch (error) {
      console.error('Error processing message:', error);
      
      // Store error response
      await Message.create({
        content: 'Sorry, I encountered an error processing your message. Please try again.',
        channel,
        phoneNumber,
        direction: 'outbound',
        status: 'failed',
        error: error.message
      });
    }

    // Send empty TwiML response
    res.type('text/xml');
    res.send('<Response></Response>');
  } catch (error) {
    console.error('Webhook error:', error);
    res.status(500).send('<Response></Response>');
  }
});

module.exports = router;