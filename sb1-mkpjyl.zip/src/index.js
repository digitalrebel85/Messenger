require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const path = require('path');
const { sequelize, initDatabase } = require('./config/database');
const webhookRouter = require('./routes/webhook');
const messagesRouter = require('./routes/messages');

const app = express();
const port = process.env.PORT || 3001;

// Basic middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/css', express.static(path.join(__dirname, '../node_modules/bootstrap/dist/css')));

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Security middleware
app.use(helmet({
  contentSecurityPolicy: false,
  crossOriginEmbedderPolicy: false,
  crossOriginResourcePolicy: false
}));

// Routes
app.use('/webhook', webhookRouter);
app.use('/messages', messagesRouter);

// Redirect root to messages
app.get('/', (req, res) => {
  res.redirect('/messages');
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'ok' });
});

// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).render('error', { 
    error: 'Internal server error',
    details: err.message
  });
});

// Function to start server
async function startServer() {
  try {
    await initDatabase();
    app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();